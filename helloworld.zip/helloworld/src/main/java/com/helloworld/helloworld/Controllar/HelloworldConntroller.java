package com.helloworld.helloworld.Controllar;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloworldConntroller {
	
	@RequestMapping(value = "/helloworld", method = RequestMethod.GET)
	private String getUsersDetails()	{
		String response = null;
		response  = "HelloWorld";
		return response;
	}

}
